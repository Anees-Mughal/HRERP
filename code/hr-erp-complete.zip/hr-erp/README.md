# HRstackPK — HR & Payroll ERP (v2)

Multi-tenant HR & Payroll system for the Pakistani market.
**Web ERP:** React + Vite · **Mobile:** React Native CLI 0.73 (bare, no Expo) · **Backend (next):** ASP.NET Core + SQL Server (stored procedures)

> **Node version: 18.12.0** — both apps are pinned and verified on it (`.nvmrc` in each folder).

---

## What's in v2

### Web ERP (`/web`)
- **Attendance** — time-in and time-out per employee, both editable inline (auto-save); marking Absent clears times
- **Payroll** — every value editable per employee (basic, HRA, medical, conveyance, tax, EOBI, loan, late deduction); overrides persist with "Reset to auto"; **Run payroll & generate payslips** writes payslip records and decrements active loans
- **Payslips** — full history (admin sees all, staff own), Print/Save PDF + **⬇ Export** (standalone HTML download)
- **Accounts** *(new)* — Transactions tab: salary expenses appear automatically **only for generated payslips**, plus manual expenses and revenue; Reports tab: **Expenses / Revenue / Profit & Loss** with month filter
- **Signup** *(web only)* — company signup at `/signup`, auto-login as owner
- **Login** — single identifier field: **Head signs in with mobile number**, **staff with email**

### Mobile app (`/mobile`)
Role detected at login — no signup in the app (web only).

**Head (mobile-number login):** dashboard with payslips-generated counter · add/edit employees · add/edit departments · mark attendance (Present/Late/Absent with in/out times) · approve/reject leaves & loans · **view-only payroll** showing Generated / Not-generated per employee (edits happen in the web ERP) · tap any employee for their payslip history

**Staff (email login):** check-in (Late after 09:15) · attendance history filtered by date from/to · apply for leave (balance cards) · apply for loan/advance · current + previous payslips

Built with **React Navigation** (native-stack + bottom-tabs), **react-native-encrypted-storage** for tokens, safe-area + keyboard handling for both **iOS and Android**.

---

## Run it

### Web
```bash
cd web && npm install && npm run dev
```
Demo logins (any password):
| Who | Identifier |
|---|---|
| Head / owner | `0300-1234567` |
| HR manager | `hr@demo.pk` |
| Staff | `emp@demo.pk` |

### Mobile (React Native CLI)
```bash
cd mobile && npm install
npx react-native run-android   # Android (emulator or device)
cd ios && pod install && cd .. && npx react-native run-ios   # iOS (Mac only)
```
Demo: head `0300-1234567` · staff `ahmed@acme.pk` (any password)

---

## Switching to the real API
Both apps run on a built-in mock by default. To use the ASP.NET Core backend:
- **Web:** set `VITE_USE_MOCK=0` and `VITE_API_URL=https://your-api` in `.env`
- **Mobile:** set `API_URL` at the top of `mobile/src/api.js`

No page/screen code changes needed — the service layer maps 1:1 to the API routes
(`/auth/login` with `identifier`, `/auth/signup`, `/payroll/overrides`, `/payroll/generate`,
`/payslips/overview`, `/attendance/mark`, `/expenses`, `/revenues`, …).

## Pakistan payroll rules built in
FBR FY2025-26 salary slabs · EOBI ₨370 employee / ₨1,850 employer · HRA 40% of basic ·
Medical 10% of basic · 3 late marks = 1 day's basic deduction · active loans auto-deduct.
